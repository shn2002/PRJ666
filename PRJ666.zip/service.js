const { User, Course, Comment } = require('./models')
const jwt = require('jsonwebtoken')
const SECRET = 'PRJ666'

const auth = async (req, res, next) => {
    const raw = String(req.headers.authorization).split(' ').pop()
    const { id } = jwt.verify(raw, SECRET)
    req.user = await User.findById(id)
    next()
}

const addCourseToUser = async (userid, course) => {
    return await User.updateOne(
        { _id: userid },
        { $addToSet: { courses:course._id } }
        
    )
}

const addUserToCourse = async (courseid, user) => {
    return await Course.updateOne(
        { _id: courseid },
        { $addToSet: { user:user._id } }
    )
}

const removeCourseToUser = async (userid, course) => {
    return await User.updateOne(
        { _id: userid },
        { $pull: { courses:course._id } }
    )
}

const removeUserToCourse = async (courseid, user) => {
    return await Course.updateOne(
        { _id: courseid },
        { $pull: { user:user._id } }
    )
}


const addCourseToComment = async (commentid, course) => {
    return await Comment.updateOne(
        { _id: commentid },
        { $set: { course:course._id } }
        
    )
}

const addCommentToCourse = async (courseid, comment) =>{
    return await Course.updateOne(
        { _id: courseid },
        { $addToSet: { comments:comment._id } }
    )
}

const removeCourseToComment = async (commentid, course) =>{
    return await Comment.updateOne(
        { _id: commentid },
        { $set: { course:null } }
        
    )
}

const removeCommentToCourse = async (courseid, comment) => {
    return await Course.updateOne(
        { _id: courseid },
        { $pull: { comments:comment._id } }
    )
}

const addCommentToUser = async (userid, comment) => {
    return await User.updateOne(
        { _id: userid },
        { $addToSet: { comments:comment._id } }
        
    )
}

const addUserToComment = async (commentid, user) => {
    return await Comment.updateOne(
        { _id: commentid },
        { $set: { user:user._id }  }
    )
}

const removeCommentToUser = async (userid, comment) => {
    return await User.updateOne(
        { _id: userid },
        { $pull: { comments:comment._id } }
        
    )
}

const removeUserToComment = async (commentid, user) => {
    return await Comment.updateOne(
        { _id: commentid },
        { $set: { user:null }  }
    )
}





module.exports.auth = auth;
module.exports.addCourseToUser = addCourseToUser;
module.exports.addUserToCourse = addUserToCourse;
module.exports.removeCourseToUser = removeCourseToUser;
module.exports.removeUserToCourse = removeUserToCourse;
module.exports.addCourseToComment = addCourseToComment;
module.exports.addCommentToCourse = addCommentToCourse;
module.exports.removeCourseToComment = removeCourseToComment;
module.exports.removeCommentToCourse = removeCommentToCourse;

module.exports.addUserToComment = addUserToComment;
module.exports.addCommentToUser = addCommentToUser;
module.exports.removeUserToComment = removeUserToComment;
module.exports.removeCommentToUser = removeCommentToUser;
